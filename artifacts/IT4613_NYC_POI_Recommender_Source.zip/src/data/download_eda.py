"""Download CRUISEResearchGroup/Massive-STEPS-New-York (tabular) and run EDA."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import matplotlib
import numpy as np
import pandas as pd
from datasets import load_dataset

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.utils.io import ensure_dir, load_yaml, save_json, save_parquet
from src.utils.seed import set_seed


def _find_col(columns: list[str], candidates: list[str]) -> str | None:
    """Return the first matching column name (exact or case-insensitive)."""
    lower_map = {c.lower(): c for c in columns}
    for cand in candidates:
        if cand in columns:
            return cand
        if cand.lower() in lower_map:
            return lower_map[cand.lower()]
    return None


def _safe_sample_rows(df: pd.DataFrame, n: int = 2) -> list[dict[str, Any]]:
    """Convert the first n rows to JSON-serializable dictionaries."""
    rows: list[dict[str, Any]] = []
    for rec in df.head(n).to_dict(orient="records"):
        clean_rec: dict[str, Any] = {}
        for k, v in rec.items():
            if isinstance(v, (np.ndarray, list, tuple)):
                seq = list(v)
                clean_rec[k] = seq[:5] if len(seq) > 5 else seq
            elif isinstance(v, (np.integer,)):
                clean_rec[k] = int(v)
            elif isinstance(v, (np.floating,)):
                clean_rec[k] = float(v)
            else:
                clean_rec[k] = v
        rows.append(clean_rec)
    return rows


def _plot_eda(
    train_df: pd.DataFrame,
    eda_dir: Path,
    detected: dict[str, str | None],
) -> list[str]:
    """Generate and save core EDA figures if relevant columns are present."""
    saved_plots: list[str] = []

    traj_col = detected.get("trajectory")
    if traj_col and traj_col in train_df.columns:
        lengths = train_df.groupby(traj_col, sort=False).size()
        fig, ax = plt.subplots(figsize=(8, 4.5))
        clipped = np.clip(lengths.to_numpy(), 1, 30)
        bins = np.arange(1, 32) - 0.5
        ax.hist(clipped, bins=bins, color="#2563eb", edgecolor="white", alpha=0.9)
        ax.set_title("Train Trajectory Length Distribution (Clipped at 30)")
        ax.set_xlabel("Check-ins per Trajectory")
        ax.set_ylabel("Number of Trajectories")
        ax.grid(axis="y", alpha=0.25)
        out_path = eda_dir / "trajectory_length_dist.png"
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)
        saved_plots.append(str(out_path))

    cat_col = detected.get("category")
    if cat_col and cat_col in train_df.columns:
        top_cats = train_df[cat_col].dropna().astype(str).value_counts().head(20)[::-1]
        if not top_cats.empty:
            fig, ax = plt.subplots(figsize=(9, 6))
            ax.barh(top_cats.index, top_cats.values, color="#0d9488")
            ax.set_title("Top 20 POI Categories in Train Split")
            ax.set_xlabel("Check-in Count")
            ax.grid(axis="x", alpha=0.25)
            out_path = eda_dir / "top_categories.png"
            fig.tight_layout()
            fig.savefig(out_path, dpi=150)
            plt.close(fig)
            saved_plots.append(str(out_path))

    lat_col = detected.get("lat")
    lon_col = detected.get("lon")
    if lat_col and lon_col and lat_col in train_df.columns and lon_col in train_df.columns:
        coords = train_df[[lat_col, lon_col]].dropna()
        if not coords.empty:
            lat_vals = coords[lat_col].to_numpy(dtype=np.float64)
            lon_vals = coords[lon_col].to_numpy(dtype=np.float64)
            # Focus on NYC bounding box percentiles to avoid global outliers skewing bins
            lat_lo, lat_hi = np.percentile(lat_vals, [0.5, 99.5])
            lon_lo, lon_hi = np.percentile(lon_vals, [0.5, 99.5])
            mask = (
                (lat_vals >= lat_lo)
                & (lat_vals <= lat_hi)
                & (lon_vals >= lon_lo)
                & (lon_vals <= lon_hi)
            )
            fig, ax = plt.subplots(figsize=(7.5, 7))
            hb = ax.hexbin(
                lon_vals[mask],
                lat_vals[mask],
                gridsize=60,
                bins="log",
                cmap="inferno",
                mincnt=1,
            )
            fig.colorbar(hb, ax=ax, label="log10(check-ins)")
            ax.set_title("NYC Check-in Spatial Density (Train Split)")
            ax.set_xlabel("Longitude")
            ax.set_ylabel("Latitude")
            out_path = eda_dir / "spatial_heatmap.png"
            fig.tight_layout()
            fig.savefig(out_path, dpi=150)
            plt.close(fig)
            saved_plots.append(str(out_path))

    return saved_plots


def run_download_and_eda(config_path: str | Path, force: bool = False) -> dict[str, Any]:
    """Download the dataset, cache splits to Parquet, and export EDA stats and plots."""
    cfg = load_yaml(config_path)
    set_seed(int(cfg.get("seed", 42)))

    raw_dir = ensure_dir(cfg["raw_dir"])
    eda_dir = ensure_dir(cfg["eda_dir"])
    dataset_name = cfg["dataset_name"]
    dataset_config = cfg["dataset_config"]

    split_dfs: dict[str, pd.DataFrame] = {}
    expected_splits = ["train", "validation", "test"]
    all_cached = all((raw_dir / f"{s}.parquet").exists() for s in expected_splits)

    if all_cached and not force:
        print(f"Loading cached raw splits from {raw_dir}")
        for split in expected_splits:
            split_dfs[split] = pd.read_parquet(raw_dir / f"{split}.parquet")
    else:
        print(f"Loading Hugging Face dataset: {dataset_name} ({dataset_config})")
        ds_dict = load_dataset(dataset_name, dataset_config)
        for split_name, ds_split in ds_dict.items():
            df = ds_split.to_pandas()
            out_pq = raw_dir / f"{split_name}.parquet"
            save_parquet(df, out_pq)
            split_dfs[split_name] = df
            print(f"Saved {split_name}: {len(df)} rows -> {out_pq}")

    train_df = split_dfs["train"]
    cols = list(train_df.columns)
    detected = {
        "user": _find_col(cols, ["user_id", "userid", "user"]),
        "poi": _find_col(cols, ["poi_id", "venue_id", "place_id", "fsq_id", "item_id"]),
        "trajectory": _find_col(
            cols, ["trail_id", "trajectory_id", "traj_id", "session_id", "sequence_id"]
        ),
        "category": _find_col(
            cols,
            [
                "venue_category_name",
                "category_name",
                "poi_category",
                "category",
                "venue_category",
            ],
        ),
        "lat": _find_col(cols, ["latitude", "lat", "venue_lat"]),
        "lon": _find_col(cols, ["longitude", "lon", "lng", "venue_lon"]),
        "timestamp": _find_col(
            cols,
            [
                "timestamp",
                "local_datetime",
                "utc_time",
                "created_at",
                "datetime",
                "checkin_time",
            ],
        ),
    }

    split_stats: dict[str, Any] = {}
    for split_name, df in split_dfs.items():
        missing = {col: int(df[col].isna().sum()) for col in df.columns}
        dtypes = {col: str(df[col].dtype) for col in df.columns}
        nunique_stats: dict[str, int] = {}
        for key, col in detected.items():
            if col and col in df.columns and key in {"user", "poi", "trajectory", "category"}:
                try:
                    nunique_stats[f"unique_{key}"] = int(df[col].nunique(dropna=True))
                except TypeError:
                    nunique_stats[f"unique_{key}"] = -1
        split_stats[split_name] = {
            "num_rows": int(len(df)),
            "columns": list(df.columns),
            "dtypes": dtypes,
            "missing_counts": missing,
            "nunique": nunique_stats,
        }

    oov_stats: dict[str, Any] = {}
    for key in ["user", "poi", "category"]:
        col = detected.get(key)
        if not col or col not in train_df.columns:
            continue
        try:
            train_set = set(train_df[col].dropna().tolist())
        except TypeError:
            continue
        oov_stats[key] = {}
        for split_name in ["validation", "test"]:
            if split_name not in split_dfs:
                continue
            vals = split_dfs[split_name][col].dropna().tolist()
            total = len(vals)
            unseen_rows = sum(1 for v in vals if v not in train_set)
            unique_vals = set(vals)
            unseen_unique = sum(1 for v in unique_vals if v not in train_set)
            oov_stats[key][split_name] = {
                "total_rows": total,
                "oov_rows": unseen_rows,
                "oov_row_rate": round(unseen_rows / max(total, 1), 6),
                "unique_entities": len(unique_vals),
                "oov_unique_entities": unseen_unique,
                "oov_unique_rate": round(unseen_unique / max(len(unique_vals), 1), 6),
            }

    saved_plots = _plot_eda(train_df, eda_dir, detected)
    summary: dict[str, Any] = {
        "dataset_name": dataset_name,
        "dataset_config": dataset_config,
        "detected_columns": detected,
        "splits": split_stats,
        "oov_relative_to_train": oov_stats,
        "train_sample_rows": _safe_sample_rows(train_df, n=2),
        "saved_plots": saved_plots,
    }
    summary_path = save_json(summary, eda_dir / "eda_summary.json")
    print(f"Saved EDA summary to {summary_path}")
    print(f"Detected columns: {detected}")
    for split_name, info in split_stats.items():
        print(f"  [{split_name}] rows={info['num_rows']}, nunique={info['nunique']}")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Download NYC Massive-STEPS and run EDA.")
    parser.add_argument("--config", type=str, default="configs/data.yaml")
    parser.add_argument("--force", action="store_true", help="Re-download raw splits.")
    args = parser.parse_args()
    run_download_and_eda(args.config, force=args.force)


if __name__ == "__main__":
    main()
