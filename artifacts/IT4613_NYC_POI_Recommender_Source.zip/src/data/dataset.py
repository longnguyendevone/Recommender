"""PyTorch Dataset and evaluation query builders for Next-POI trajectories."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from src.utils.io import load_parquet


class NextPOIDataset(Dataset):
    """Sequence dataset with left-padding, spatio-temporal features, and negative sampling."""

    def __init__(
        self,
        sequences_path: str | Path,
        num_pois: int,
        max_seq_len: int = 50,
        num_negatives: int = 64,
        mode: str = "train",
        seed: int = 42,
    ) -> None:
        if mode not in {"train", "eval"}:
            raise ValueError(f"Unsupported dataset mode: {mode}")
        self.mode = mode
        self.num_pois = int(num_pois)
        self.max_seq_len = int(max_seq_len)
        self.num_negatives = int(num_negatives)
        self.rng = np.random.default_rng(seed)

        df = load_parquet(sequences_path)
        self.trail_ids = df["trail_id"].tolist()
        self.user_indices = df["user_idx"].to_numpy(dtype=np.int64)
        self.poi_seqs = [np.asarray(x, dtype=np.int64) for x in df["poi_seq"]]
        self.cat_seqs = [np.asarray(x, dtype=np.int64) for x in df["cat_seq"]]
        self.lat_seqs = [np.asarray(x, dtype=np.float64) for x in df["lat_seq"]]
        self.lon_seqs = [np.asarray(x, dtype=np.float64) for x in df["lon_seq"]]
        self.hour_sin_seqs = [np.asarray(x, dtype=np.float32) for x in df["hour_sin_seq"]]
        self.hour_cos_seqs = [np.asarray(x, dtype=np.float32) for x in df["hour_cos_seq"]]
        self.dow_sin_seqs = [np.asarray(x, dtype=np.float32) for x in df["dow_sin_seq"]]
        self.dow_cos_seqs = [np.asarray(x, dtype=np.float32) for x in df["dow_cos_seq"]]
        self.delta_dist_seqs = [np.asarray(x, dtype=np.float32) for x in df["delta_dist_seq"]]
        self.delta_time_seqs = [np.asarray(x, dtype=np.float32) for x in df["delta_time_seq"]]

    def __len__(self) -> int:
        return len(self.poi_seqs)

    def _encode_prefix(
        self, idx: int, prefix_len: int
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, int]:
        """Extract and left-pad input sequence arrays of length <= max_seq_len."""
        start = max(0, prefix_len - self.max_seq_len)
        end = prefix_len
        used_len = end - start

        poi_pad = np.zeros(self.max_seq_len, dtype=np.int64)
        cat_pad = np.zeros(self.max_seq_len, dtype=np.int64)
        time_pad = np.zeros((self.max_seq_len, 4), dtype=np.float32)
        delta_pad = np.zeros((self.max_seq_len, 2), dtype=np.float32)

        offset = self.max_seq_len - used_len
        poi_pad[offset:] = self.poi_seqs[idx][start:end]
        cat_pad[offset:] = self.cat_seqs[idx][start:end]
        time_pad[offset:, 0] = self.hour_sin_seqs[idx][start:end]
        time_pad[offset:, 1] = self.hour_cos_seqs[idx][start:end]
        time_pad[offset:, 2] = self.dow_sin_seqs[idx][start:end]
        time_pad[offset:, 3] = self.dow_cos_seqs[idx][start:end]
        delta_pad[offset:, 0] = np.log1p(np.maximum(0.0, self.delta_dist_seqs[idx][start:end]))
        delta_pad[offset:, 1] = np.log1p(np.maximum(0.0, self.delta_time_seqs[idx][start:end]))
        return poi_pad, cat_pad, time_pad, delta_pad, used_len

    def _sample_negatives(self, positive_set: set[int]) -> np.ndarray:
        """Sample negatives in [2, num_pois - 1] avoiding positives in the trail."""
        neg = self.rng.integers(2, self.num_pois, size=(self.max_seq_len, self.num_negatives))
        if positive_set:
            pos_arr = np.fromiter(positive_set, dtype=np.int64)
            mask = np.isin(neg, pos_arr)
            while mask.any():
                neg[mask] = self.rng.integers(2, self.num_pois, size=int(mask.sum()))
                mask = np.isin(neg, pos_arr)
        return neg.astype(np.int64)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        full_poi = self.poi_seqs[idx]
        prefix_len = len(full_poi) - 1
        poi_pad, cat_pad, time_pad, delta_pad, used_len = self._encode_prefix(idx, prefix_len)

        if self.mode == "train":
            start = max(0, prefix_len - self.max_seq_len)
            tgt_slice = full_poi[start + 1 : prefix_len + 1]
            targets = np.zeros(self.max_seq_len, dtype=np.int64)
            targets[self.max_seq_len - used_len :] = tgt_slice

            positives = {int(p) for p in full_poi if p >= 2}
            negatives = self._sample_negatives(positives)

            return {
                "poi_seq": torch.from_numpy(poi_pad),
                "cat_seq": torch.from_numpy(cat_pad),
                "time_feats": torch.from_numpy(time_pad),
                "delta_feats": torch.from_numpy(delta_pad),
                "targets": torch.from_numpy(targets),
                "negatives": torch.from_numpy(negatives),
                "user_idx": torch.tensor(self.user_indices[idx], dtype=torch.long),
                "seq_len": torch.tensor(used_len, dtype=torch.long),
            }

        target = int(full_poi[-1])
        last_lat = float(self.lat_seqs[idx][-2])
        last_lon = float(self.lon_seqs[idx][-2])
        return {
            "poi_seq": torch.from_numpy(poi_pad),
            "cat_seq": torch.from_numpy(cat_pad),
            "time_feats": torch.from_numpy(time_pad),
            "delta_feats": torch.from_numpy(delta_pad),
            "target": torch.tensor(target, dtype=torch.long),
            "user_idx": torch.tensor(self.user_indices[idx], dtype=torch.long),
            "last_lat": torch.tensor(last_lat, dtype=torch.float64),
            "last_lon": torch.tensor(last_lon, dtype=torch.float64),
            "seq_len": torch.tensor(used_len, dtype=torch.long),
        }


def build_eval_queries(sequences_df: pd.DataFrame) -> list[dict[str, Any]]:
    """Convert a sequences DataFrame into lightweight evaluation query dicts."""
    queries: list[dict[str, Any]] = []
    for row in sequences_df.itertuples(index=False):
        poi_seq = list(row.poi_seq)
        cat_seq = list(row.cat_seq)
        lat_seq = list(row.lat_seq)
        lon_seq = list(row.lon_seq)
        hour_sin_seq = list(row.hour_sin_seq)
        hour_cos_seq = list(row.hour_cos_seq)
        dow_sin_seq = list(row.dow_sin_seq)
        dow_cos_seq = list(row.dow_cos_seq)

        queries.append(
            {
                "trail_id": str(row.trail_id),
                "user_idx": int(row.user_idx),
                "poi_seq": [int(p) for p in poi_seq[:-1]],
                "cat_seq": [int(c) for c in cat_seq[:-1]],
                "hour_sin_seq": [float(x) for x in hour_sin_seq[:-1]],
                "hour_cos_seq": [float(x) for x in hour_cos_seq[:-1]],
                "dow_sin_seq": [float(x) for x in dow_sin_seq[:-1]],
                "dow_cos_seq": [float(x) for x in dow_cos_seq[:-1]],
                "delta_dist_seq": [float(x) for x in list(row.delta_dist_seq)[:-1]],
                "delta_time_seq": [float(x) for x in list(row.delta_time_seq)[:-1]],
                "last_lat": float(lat_seq[-2]),
                "last_lon": float(lon_seq[-2]),
                "hour_sin": float(hour_sin_seq[-2]),
                "hour_cos": float(hour_cos_seq[-2]),
                "dow_sin": float(dow_sin_seq[-2]),
                "dow_cos": float(dow_cos_seq[-2]),
                "target_poi_idx": int(poi_seq[-1]),
            }
        )
    return queries
