"""Preprocess Massive-STEPS NYC raw splits into train-only ID mappings, metadata, and sequences."""

from __future__ import annotations

import argparse
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.utils.geo import build_ball_tree, haversine_km
from src.utils.io import ensure_dir, load_parquet, load_yaml, save_json, save_parquet
from src.utils.seed import set_seed

PAD_IDX = 0
OOV_IDX = 1


def _impute_missing(df: pd.DataFrame) -> pd.DataFrame:
    """Deterministically impute missing coordinates, names, and addresses."""
    out = df.copy()
    has_exact = out["latitude"].notna() & out["longitude"].notna()
    out["has_exact_coords"] = has_exact.astype(bool)

    out["latitude"] = out["latitude"].fillna(out["venue_city_latitude"]).astype(np.float64)
    out["longitude"] = out["longitude"].fillna(out["venue_city_longitude"]).astype(np.float64)

    missing_name = out["name"].isna()
    if missing_name.any():
        fallback_names = (
            out.loc[missing_name, "venue_category"].astype(str)
            + " ("
            + out.loc[missing_name, "venue_city"].astype(str)
            + ") #"
            + out.loc[missing_name, "venue_id"].astype(str)
        )
        out.loc[missing_name, "name"] = fallback_names

    out["address"] = out["address"].fillna(out["venue_city"]).astype(str)
    out["name"] = out["name"].astype(str)
    out["venue_category"] = out["venue_category"].astype(str)
    out["venue_city"] = out["venue_city"].astype(str)
    return out


def _fit_mappings(train_df: pd.DataFrame) -> dict[str, Any]:
    """Fit deterministic ID mappings strictly on the training split."""
    unique_users = sorted(int(u) for u in train_df["user_id"].unique().tolist())
    unique_pois = sorted(int(p) for p in train_df["venue_id"].unique().tolist())
    unique_cats = sorted(str(c) for c in train_df["venue_category"].unique().tolist())

    user2idx = {str(u): idx + 2 for idx, u in enumerate(unique_users)}
    poi2idx = {str(p): idx + 2 for idx, p in enumerate(unique_pois)}
    cat2idx = {c: idx + 2 for idx, c in enumerate(unique_cats)}

    return {
        "pad_idx": PAD_IDX,
        "oov_idx": OOV_IDX,
        "num_users": len(unique_users) + 2,
        "num_pois": len(unique_pois) + 2,
        "num_cats": len(unique_cats) + 2,
        "user2idx": user2idx,
        "poi2idx": poi2idx,
        "cat2idx": cat2idx,
    }


def _build_poi_metadata(
    train_df: pd.DataFrame,
    poi2idx_int: dict[int, int],
    cat2idx: dict[str, int],
) -> pd.DataFrame:
    """Build one metadata row per train POI, sorted by poi_idx (2..num_pois-1)."""
    pop_counts = train_df.groupby("venue_id", sort=False).size().rename("train_popularity")

    # Prefer rows with exact coordinates when deduplicating venue_id metadata.
    ordered = train_df.sort_values(
        by=["venue_id", "has_exact_coords"],
        ascending=[True, False],
        kind="mergesort",
    )
    meta = ordered.drop_duplicates(subset=["venue_id"], keep="first").copy()
    meta["poi_idx"] = meta["venue_id"].map(poi2idx_int).astype(np.int64)
    meta["cat_idx"] = meta["venue_category"].map(cat2idx).fillna(OOV_IDX).astype(np.int64)
    meta["train_popularity"] = meta["venue_id"].map(pop_counts).astype(np.int64)

    meta = meta.rename(
        columns={
            "venue_category": "category",
            "latitude": "lat",
            "longitude": "lon",
            "venue_city": "city",
        }
    )
    keep_cols = [
        "poi_idx",
        "venue_id",
        "name",
        "category",
        "cat_idx",
        "lat",
        "lon",
        "address",
        "city",
        "has_exact_coords",
        "train_popularity",
    ]
    meta = meta[keep_cols].sort_values("poi_idx", kind="mergesort").reset_index(drop=True)
    return meta


def _transform_checkins(
    df: pd.DataFrame,
    user2idx_int: dict[int, int],
    poi2idx_int: dict[int, int],
    cat2idx: dict[str, int],
) -> pd.DataFrame:
    """Add ID indices, cyclical temporal features, and step-to-step deltas."""
    out = df.copy()
    out["dt"] = pd.to_datetime(out["timestamp"])
    out = out.sort_values(["trail_id", "dt"], kind="mergesort").reset_index(drop=True)

    out["user_idx"] = out["user_id"].map(user2idx_int).fillna(OOV_IDX).astype(np.int64)
    out["poi_idx"] = out["venue_id"].map(poi2idx_int).fillna(OOV_IDX).astype(np.int64)
    out["cat_idx"] = out["venue_category"].map(cat2idx).fillna(OOV_IDX).astype(np.int64)

    hour_float = out["dt"].dt.hour.to_numpy(dtype=np.float64) + (
        out["dt"].dt.minute.to_numpy(dtype=np.float64) / 60.0
    )
    dow = out["dt"].dt.dayofweek.to_numpy(dtype=np.float64)

    out["hour_sin"] = np.sin(2.0 * np.pi * hour_float / 24.0).astype(np.float32)
    out["hour_cos"] = np.cos(2.0 * np.pi * hour_float / 24.0).astype(np.float32)
    out["dow_sin"] = np.sin(2.0 * np.pi * dow / 7.0).astype(np.float32)
    out["dow_cos"] = np.cos(2.0 * np.pi * dow / 7.0).astype(np.float32)

    grouped = out.groupby("trail_id", sort=False)
    prev_lat = grouped["latitude"].shift(1)
    prev_lon = grouped["longitude"].shift(1)
    prev_dt = grouped["dt"].shift(1)

    is_first = prev_lat.isna()
    dist = haversine_km(
        prev_lat.fillna(out["latitude"]).to_numpy(dtype=np.float64),
        prev_lon.fillna(out["longitude"]).to_numpy(dtype=np.float64),
        out["latitude"].to_numpy(dtype=np.float64),
        out["longitude"].to_numpy(dtype=np.float64),
    )
    dist = np.where(is_first.to_numpy(), 0.0, dist).astype(np.float32)

    time_diff_min = (out["dt"] - prev_dt).dt.total_seconds().div(60.0).fillna(0.0)
    time_diff_min = np.clip(time_diff_min.to_numpy(dtype=np.float32), 0.0, 10080.0)

    out["delta_dist_km"] = dist
    out["delta_time_min"] = time_diff_min
    out["timestamp_unix"] = (out["dt"].astype("int64") // 10**9).astype(np.int64)
    return out.drop(columns=["dt"])


def _build_sequences(checkins_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate chronological check-ins into trail sequences of length >= 2."""
    trail_ids: list[str] = []
    user_ids: list[int] = []
    user_indices: list[int] = []
    seq_lens: list[int] = []
    poi_seqs: list[list[int]] = []
    cat_seqs: list[list[int]] = []
    lat_seqs: list[list[float]] = []
    lon_seqs: list[list[float]] = []
    hour_sin_seqs: list[list[float]] = []
    hour_cos_seqs: list[list[float]] = []
    dow_sin_seqs: list[list[float]] = []
    dow_cos_seqs: list[list[float]] = []
    delta_dist_seqs: list[list[float]] = []
    delta_time_seqs: list[list[float]] = []

    for trail_id, grp in checkins_df.groupby("trail_id", sort=False):
        n = len(grp)
        if n < 2:
            continue
        trail_ids.append(str(trail_id))
        user_ids.append(int(grp["user_id"].iloc[0]))
        user_indices.append(int(grp["user_idx"].iloc[0]))
        seq_lens.append(int(n))
        poi_seqs.append(grp["poi_idx"].tolist())
        cat_seqs.append(grp["cat_idx"].tolist())
        lat_seqs.append(grp["latitude"].tolist())
        lon_seqs.append(grp["longitude"].tolist())
        hour_sin_seqs.append(grp["hour_sin"].tolist())
        hour_cos_seqs.append(grp["hour_cos"].tolist())
        dow_sin_seqs.append(grp["dow_sin"].tolist())
        dow_cos_seqs.append(grp["dow_cos"].tolist())
        delta_dist_seqs.append(grp["delta_dist_km"].tolist())
        delta_time_seqs.append(grp["delta_time_min"].tolist())

    return pd.DataFrame(
        {
            "trail_id": trail_ids,
            "user_id": user_ids,
            "user_idx": user_indices,
            "seq_len": seq_lens,
            "poi_seq": poi_seqs,
            "cat_seq": cat_seqs,
            "lat_seq": lat_seqs,
            "lon_seq": lon_seqs,
            "hour_sin_seq": hour_sin_seqs,
            "hour_cos_seq": hour_cos_seqs,
            "dow_sin_seq": dow_sin_seqs,
            "dow_cos_seq": dow_cos_seqs,
            "delta_dist_seq": delta_dist_seqs,
            "delta_time_seq": delta_time_seqs,
        }
    )


def run_preprocess(config_path: str | Path) -> dict[str, Any]:
    """Run full preprocessing pipeline and save artifacts to data/processed/."""
    cfg = load_yaml(config_path)
    set_seed(int(cfg.get("seed", 42)))

    raw_dir = Path(cfg["raw_dir"])
    out_dir = ensure_dir(cfg["processed_dir"])

    raw_splits = {
        split: _impute_missing(load_parquet(raw_dir / f"{split}.parquet"))
        for split in ("train", "validation", "test")
    }

    mappings = _fit_mappings(raw_splits["train"])
    save_json(mappings, out_dir / "mappings.json")

    user2idx_int = {int(k): int(v) for k, v in mappings["user2idx"].items()}
    poi2idx_int = {int(k): int(v) for k, v in mappings["poi2idx"].items()}
    cat2idx = {str(k): int(v) for k, v in mappings["cat2idx"].items()}

    poi_meta = _build_poi_metadata(raw_splits["train"], poi2idx_int, cat2idx)
    save_parquet(poi_meta, out_dir / "poi_metadata.parquet")

    coords = poi_meta[["lat", "lon"]].to_numpy(dtype=np.float64)
    ball_tree = build_ball_tree(coords)
    with open(out_dir / "poi_balltree.pkl", "wb") as f:
        pickle.dump(
            {
                "tree": ball_tree,
                "poi_indices": poi_meta["poi_idx"].to_numpy(dtype=np.int64),
            },
            f,
        )

    stats: dict[str, Any] = {
        "num_users": mappings["num_users"],
        "num_pois": mappings["num_pois"],
        "num_cats": mappings["num_cats"],
        "num_catalog_pois": len(poi_meta),
        "splits": {},
    }

    for split_name, df in raw_splits.items():
        checkins = _transform_checkins(df, user2idx_int, poi2idx_int, cat2idx)
        save_parquet(checkins, out_dir / f"{split_name}_checkins.parquet")

        seqs = _build_sequences(checkins)
        save_parquet(seqs, out_dir / f"{split_name}_sequences.parquet")

        targets = np.array([seq[-1] for seq in seqs["poi_seq"]], dtype=np.int64)
        oov_target_rate = float((targets == OOV_IDX).mean()) if len(targets) > 0 else 0.0
        stats["splits"][split_name] = {
            "num_checkins": int(len(checkins)),
            "num_sequences": int(len(seqs)),
            "oov_target_rate": round(oov_target_rate, 6),
        }
        print(
            f"[{split_name}] checkins={len(checkins)}, "
            f"sequences(len>=2)={len(seqs)}, oov_target_rate={oov_target_rate:.4%}"
        )

    save_json(stats, out_dir / "preprocess_stats.json")
    print(
        f"Preprocessing complete: catalog_pois={len(poi_meta)}, "
        f"num_users={mappings['num_users']}, num_cats={mappings['num_cats']}"
    )
    return stats


def main() -> None:
    parser = argparse.ArgumentParser(description="Preprocess Massive-STEPS NYC dataset.")
    parser.add_argument("--config", type=str, default="configs/data.yaml")
    args = parser.parse_args()
    run_preprocess(args.config)


if __name__ == "__main__":
    main()
