"""FastAPI inference backend package."""
