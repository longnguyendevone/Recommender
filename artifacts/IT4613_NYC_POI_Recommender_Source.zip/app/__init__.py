"""Web prototype package."""
